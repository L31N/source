
#define	BOOTLOADER_TYPE			0
#define	BOOT_LED				B,7

