
// ----------------------------------------------------------------------------
// Bootloader Settings

#define	BOOTLOADER_TYPE		0

#define	BOOT_LED			B,1

//#define	BOOT_INIT
//#define	BOOT_LED_SET_OUTPUT
//#define	BOOT_LED_ON
//#define	BOOT_LED_OFF
//#define	BOOT_LED_TOGGLE

// ----------------------------------------------------------------------------
// CAN Settings

#define	MCP2515_CS			B,4
#define	MCP2515_INT			B,2
