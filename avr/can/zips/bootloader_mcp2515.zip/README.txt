Eine genaue Dokumentation gibt es auf meiner Homepage unter:
http://www.kreatives-chaos.com/artikel/can-bootloader

Die Datei 'bootloader.hex' ist für einen ATMega644 (14,7456 MHz) auf dem 
CAN Testboard 40v2 vorgesehen. Als Bootloader-LED wird LED5 an PB0 
(Lötjumper SJ3 schließen) verwendet. Die Bootloader Adresse ist auf '0xff'
eingestellt.

Wer andere Einstellungen verwenden will muss sich den Bootloader neu 
compilieren. Siehe http://www.kreatives-chaos.com/artikel/can-bootloader#compilieren

Viel Spaß mit dem Bootloader ;-)

